package com.zhuxiaoxuan.model;

public class MailType {
	private int mailtypeId;
	private String mailtypeName;
	private String mailtypeDesc;
	public int getMailtypeId() {
		return mailtypeId;
	}
	public void setMailtypeId(int mailtypeId) {
		this.mailtypeId = mailtypeId;
	}
	public String getMailtypeName() {
		return mailtypeName;
	}
	public void setMailtypeName(String mailtypeName) {
		this.mailtypeName = mailtypeName;
	}
	public String getMailtypeDesc() {
		return mailtypeDesc;
	}
	public void setMailtypeDesc(String mailtypeDesc) {
		this.mailtypeDesc = mailtypeDesc;
	}
}
